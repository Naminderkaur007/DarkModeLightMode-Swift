//
//  FavViewController.swift
//  PracticeProject
//
//  Created by Naminder Kaur on 07/07/22.
//

import UIKit

class FavViewController: UIViewController {

    @IBOutlet weak var modelbl: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
                
        print("I m viewWillAppear")
        if self.traitCollection.userInterfaceStyle == .dark {
                    // User Interface is Dark
            print("dark mode")
            self.modelbl.text = "Dark Mode"
                } else {
                    // User Interface is Light
                    print("light mode")
                    self.modelbl.text = "Light Mode"
                }
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
           // Trait collection has already changed
        print("traitCollectionDidChange")
        if self.traitCollection.userInterfaceStyle == .dark {
                    // User Interface is Dark
            print("dark mode")
            self.modelbl.text = "Dark Mode"
                } else {
                    // User Interface is Light
                    print("light mode")
                    self.modelbl.text = "Light Mode"
                }
       }

}
